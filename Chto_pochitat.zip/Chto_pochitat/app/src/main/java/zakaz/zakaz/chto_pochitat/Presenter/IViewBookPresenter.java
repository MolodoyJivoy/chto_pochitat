package zakaz.zakaz.chto_pochitat.Presenter;

public interface IViewBookPresenter {
    void onBook();
}
