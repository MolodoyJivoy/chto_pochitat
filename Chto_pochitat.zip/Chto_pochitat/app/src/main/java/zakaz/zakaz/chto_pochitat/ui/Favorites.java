package zakaz.zakaz.chto_pochitat.ui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.List;

import io.paperdb.Paper;
import zakaz.zakaz.chto_pochitat.Adapter.FavoritesItem;
import zakaz.zakaz.chto_pochitat.Adapter.MainFavoritesAdapter;
import zakaz.zakaz.chto_pochitat.Model.Book;
import zakaz.zakaz.chto_pochitat.R;
import zakaz.zakaz.chto_pochitat.View.IFavorites;

public class Favorites extends Fragment implements IFavorites {

    private ListView MainFavorite, OtherFavorite;
    private List<FavoritesItem> maintList, otherList;

    private TextView chekOnNull;

    List<Book> list;

    MainFavoritesAdapter mainFavoritesAdapter;

    private static int counter = 0;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup viewGroup = (ViewGroup)inflater.inflate(R.layout.activity_favorites, container, false);
        MainFavorite = viewGroup.findViewById(R.id.MainFavorite);
        chekOnNull = viewGroup.findViewById(R.id.checkFavorites);
        Paper.init(getContext());
        maintList = new ArrayList<>();
        otherList = new ArrayList<>();

        getData();

        mainFavoritesAdapter = new MainFavoritesAdapter(getContext(), maintList);
        MainFavorite.setAdapter(mainFavoritesAdapter);

        return viewGroup;
    }

    private void checkOnNull() {
        if (maintList.isEmpty()){
            chekOnNull.setVisibility(View.VISIBLE);
        }else {
            chekOnNull.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onRefresh() {
        maintList.clear();
        getData();
        mainFavoritesAdapter.notifyDataSetChanged();
    }

    void getData(){
        List<String> keys = Paper.book("books").getAllKeys();
        if (!keys.isEmpty()){
            for (int i = 0 ; i < keys.size(); i++){
                Book list = Paper.book("books").read(keys.get(i));
                maintList.add(new FavoritesItem(list.getBook(), list.getAuthor()));
            }
        }
        checkOnNull();
    }
}
