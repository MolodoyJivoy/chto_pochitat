package zakaz.zakaz.chto_pochitat.View;

public interface IFavorites {
    void onRefresh();
}
