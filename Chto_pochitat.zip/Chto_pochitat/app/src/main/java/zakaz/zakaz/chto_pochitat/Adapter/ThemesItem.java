package zakaz.zakaz.chto_pochitat.Adapter;

public class ThemesItem {
    private String NameThemes;

    public ThemesItem(String nameThemes) {
        NameThemes = nameThemes;
    }

    public String getNameThemes() {
        return NameThemes;
    }
}
